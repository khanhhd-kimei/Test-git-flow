#! /usr/bin/python

import json
from collections import OrderedDict
from pprint import pprint

locales = {
	"fr": "fr_FR",
	"ge": "de_DE",
	"it": "it_IT",
	"po": "pl_PL",
	"ru": "ru_RU",
	"sp": "es_ES"
}

json_file='shop-list-en_GB.json'
mapping_file='mapping.json'

with open(mapping_file) as mapping_load:
	with open(json_file) as json_load:
		shoplist_data = json.load(json_load)
		mapping_data = json.load(mapping_load)

		for key, locale in locales.items():
			data = []

			for shoplist in  shoplist_data:
				tmp = OrderedDict(shoplist)
				tmp["name"] = mapping_data[shoplist["name"].upper()][key].title()
				data.append(tmp)

			output_filename = "shop-list-" + locale + ".json"
			with open(output_filename, 'w') as outfile:
				json.dump(data, outfile)
				